package com.example.appcontactos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class CreaModificaContacto extends AppCompatActivity {
    public static final String EXTRA_ID = "idCM";
    public static final String EXTRA_NOMBRE = "nombreCM";
    public static final String EXTRA_TELEFONO = "telefonoCM";
    public static final String EXTRA_EMAIL = "emailCM";
    public static final String EXTRA_DIRECCION = "direccionCM";

    private EditText textNombre, textTelefono, textEmail, textDireccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crea_modifica_contacto);

        textNombre = (EditText) findViewById(R.id.etNombreNuevo);
        textTelefono = (EditText) findViewById(R.id.etTelefonoNuevo);
        textEmail = (EditText) findViewById(R.id.etEmailNuevo);
        textDireccion = (EditText) findViewById(R.id.etDireccionNuevo);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            setTitle("Editar contacto");
            textNombre.setText(intent.getStringExtra(EXTRA_NOMBRE));
            textTelefono.setText(intent.getStringExtra(EXTRA_TELEFONO));
            textEmail.setText(intent.getStringExtra(EXTRA_EMAIL));
            textDireccion.setText(intent.getStringExtra(EXTRA_DIRECCION));
        } else {
            setTitle("Nuevo contacto");
        }
    }

    private void guardaContacto() {

            String nombre = textNombre.getText().toString();
            String telefono = textTelefono.getText().toString();
            String email = textEmail.getText().toString();
            String direccion = textDireccion.getText().toString();


        if (isAnyEmpty()) {
            Toast.makeText(this, "Faltan datos", Toast.LENGTH_SHORT).show();
            finish();
        }
        Intent data = new Intent();
        data.putExtra(EXTRA_NOMBRE, nombre);
        data.putExtra(EXTRA_TELEFONO, telefono);
        data.putExtra(EXTRA_EMAIL, email);
        data.putExtra(EXTRA_DIRECCION, direccion);


        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            data.putExtra(EXTRA_ID, id);
        }

        setResult(RESULT_OK, data);

        finish();



    }

    private boolean isAnyEmpty() {
        return TextUtils.isEmpty(textNombre.getText()) || TextUtils.isEmpty(textTelefono.getText())
                || TextUtils.isEmpty(textEmail.getText()) || TextUtils.isEmpty(textDireccion.getText());
    }

    // Crear el menú
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.contacto_nuevo_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.guardarContacto:
                guardaContacto();
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}