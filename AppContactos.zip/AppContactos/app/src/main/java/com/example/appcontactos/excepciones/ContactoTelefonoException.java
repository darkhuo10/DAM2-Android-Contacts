package com.example.appcontactos.excepciones;

public class ContactoTelefonoException extends ContactoException{
    public ContactoTelefonoException() {
        super();
    }

    public ContactoTelefonoException(String message) {
        super(message);
    }
}
