package com.example.appcontactos.repositorio;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.appcontactos.conexionbd.Contacto;
import com.example.appcontactos.conexionbd.ContactoDAO;
import com.example.appcontactos.conexionbd.ContactosBD;

import java.util.List;

public class RepositorioContactosBD {
    private ContactoDAO contactoDAO;
    private LiveData<List<Contacto>> allContactos;

    public RepositorioContactosBD(Application app){
        ContactosBD contactosBD =ContactosBD.getContactosBD(app);
        contactoDAO = contactosBD.contactoDAO();
        allContactos = contactoDAO.selecctAll();
    }

    public LiveData<List<Contacto>> getAllContactos() {
        return allContactos;
    }

    public void insertaContacto(Contacto contactoInsertar){
        ContactosBD.escritorBD.execute(() -> contactoDAO.insert(contactoInsertar));
    }
    public void eliminaContacto(Contacto contactoBorrar){
        ContactosBD.escritorBD.execute(() -> contactoDAO.delete(contactoBorrar));
    }
    public void modificaContacto(Contacto contactoModificar){
        ContactosBD.escritorBD.execute(() -> contactoDAO.update(contactoModificar));
    }
}
