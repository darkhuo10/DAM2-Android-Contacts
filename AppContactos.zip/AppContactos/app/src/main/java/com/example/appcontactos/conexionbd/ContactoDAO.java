package com.example.appcontactos.conexionbd;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ContactoDAO {
    @Insert
    void insert(Contacto contacto);

    @Delete
    void delete(Contacto contacto);

    @Update
    void update(Contacto contacto);

    @Query("SELECT * FROM contactos_table ORDER BY nombre")
    LiveData<List<Contacto>> selecctAll();

    @Query("DELETE FROM contactos_table")
    void deleteAll();
}
