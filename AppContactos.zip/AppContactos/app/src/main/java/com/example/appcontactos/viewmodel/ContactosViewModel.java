package com.example.appcontactos.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.appcontactos.conexionbd.Contacto;
import com.example.appcontactos.repositorio.RepositorioContactosBD;

import java.util.List;

public class ContactosViewModel extends AndroidViewModel {
    private RepositorioContactosBD repositorioContactosBD;
    private LiveData<List<Contacto>> todosContactos;

    public ContactosViewModel(@NonNull Application application) {
        super(application);
        repositorioContactosBD = new RepositorioContactosBD(application);
        todosContactos = repositorioContactosBD.getAllContactos();
    }

    public LiveData<List<Contacto>> getTodosContactos(){
        return todosContactos;
    }


    public void insertContacto(Contacto cInsertar) {
        repositorioContactosBD.insertaContacto(cInsertar);
    }

    public void deleteContacto(Contacto cBorrar){
        repositorioContactosBD.eliminaContacto(cBorrar);
    }
    public void updateContacto(Contacto cModificar){
        repositorioContactosBD.modificaContacto(cModificar);
    }

}
