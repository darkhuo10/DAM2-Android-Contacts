package com.example.appcontactos.excepciones;

public class ContactoEmailException extends ContactoException{
    public ContactoEmailException() {
        super();
    }

    public ContactoEmailException(String message) {
        super(message);
    }
}
