package com.example.appcontactos;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.appcontactos.adaptador.ContactosAdapter;
import com.example.appcontactos.conexionbd.Contacto;
import com.example.appcontactos.excepciones.ContactoException;
import com.example.appcontactos.viewmodel.ContactosViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public static final int CODE_CREA_CONTACTO = 1;
    public static final int CODE_MODIFICA_CONTACTO = 2;
    RecyclerView listaContactos;
    public ContactosViewModel contactosViewModel;
    public ContactosAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton bNuevoContacto = findViewById(R.id.bAdd);
        bNuevoContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prepararContactoCrear();
            }
        });

        listaContactos = (RecyclerView) findViewById(R.id.rvListaContactos);
        listaContactos.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ContactosAdapter();
        listaContactos.setAdapter(adapter);


        contactosViewModel = new ViewModelProvider(this).get(ContactosViewModel.class);
        setListaRecyclerView();

        // Detecta las acciones hechas en el recycler view, LEFT y RIGTH para que se detecten deslizamientos a ambos lados
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                alertBorrar(viewHolder);
            }

        }).attachToRecyclerView(listaContactos);

        adapter.setOnClickContactoListener(contacto -> prepararContactoModificar(contacto));

    }

    private void prepararContactoCrear() {
        Intent intent = new Intent(MainActivity.this, CreaModificaContacto.class);
        startActivityForResult(intent, CODE_CREA_CONTACTO);
    }

    private void prepararContactoModificar(Contacto contacto) {
        Intent intent = new Intent(MainActivity.this, CreaModificaContacto.class);

        intent.putExtra(CreaModificaContacto.EXTRA_ID, contacto.getId());
        intent.putExtra(CreaModificaContacto.EXTRA_NOMBRE, contacto.getNombre());
        intent.putExtra(CreaModificaContacto.EXTRA_TELEFONO, contacto.getTelefono());
        intent.putExtra(CreaModificaContacto.EXTRA_EMAIL, contacto.getEmail());
        intent.putExtra(CreaModificaContacto.EXTRA_DIRECCION, contacto.getDireccion());

        startActivityForResult(intent, CODE_MODIFICA_CONTACTO);
    }

    private void alertBorrar(RecyclerView.ViewHolder viewHolder) {
        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        alert.setTitle("Atención");
        alert.setMessage("¿Desea borrar el contacto?");
        alert.setCancelable(false);
        alert.setPositiveButton("Confirmar", (dialogInterface, i) -> eliminarContacto(viewHolder));
        alert.setNegativeButton("Cancelar", (dialogInterface, i) -> mantenerContacto(dialogInterface));
        alert.show();
    }

    private void mantenerContacto(DialogInterface dialogInterface) {
        dialogInterface.dismiss();
        // añadir de nuevo la list al rv
        setListaRecyclerView();
        Toast.makeText(MainActivity.this, "Operación cancelada", Toast.LENGTH_SHORT).show();
    }

    private void setListaRecyclerView() {
        contactosViewModel.getTodosContactos().observe(this, contactos -> {
            adapter.setContactos(contactos);
        });
    }

    private void eliminarContacto(RecyclerView.ViewHolder viewHolder) {
        contactosViewModel.deleteContacto(adapter.getContactoPos(viewHolder.getAdapterPosition()));
        Toast.makeText(MainActivity.this, "Contacto eliminado", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Contacto contacto;
        if (requestCode == CODE_CREA_CONTACTO && resultCode == RESULT_OK) {
            String nombre = data.getStringExtra(CreaModificaContacto.EXTRA_NOMBRE);
            String telefono = data.getStringExtra(CreaModificaContacto.EXTRA_TELEFONO);
            String email = data.getStringExtra(CreaModificaContacto.EXTRA_EMAIL);
            String direccion = data.getStringExtra(CreaModificaContacto.EXTRA_DIRECCION);


            try {
                contacto = new Contacto(nombre, telefono, email, direccion);
                contactosViewModel.insertContacto(contacto);
                Toast.makeText(this, "Guardado", Toast.LENGTH_LONG).show();
            } catch (ContactoException e) {
                setListaRecyclerView();
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        } else if (requestCode == CODE_MODIFICA_CONTACTO && resultCode == RESULT_OK) {
            int id = data.getIntExtra(CreaModificaContacto.EXTRA_ID, -1);


            String nombre = data.getStringExtra(CreaModificaContacto.EXTRA_NOMBRE);
            String telefono = data.getStringExtra(CreaModificaContacto.EXTRA_TELEFONO);
            String email = data.getStringExtra(CreaModificaContacto.EXTRA_EMAIL);
            String direccion = data.getStringExtra(CreaModificaContacto.EXTRA_DIRECCION);

            try {
                contacto = new Contacto(nombre, telefono, email, direccion);
                contacto.setId(id);
                contactosViewModel.updateContacto(contacto);
                Toast.makeText(this, "Guardado", Toast.LENGTH_LONG).show();
            } catch (ContactoException e) {


                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }


        } else {
            Toast.makeText(this, "No guardado", Toast.LENGTH_LONG).show();
        }
    }
}