package com.example.appcontactos.excepciones;

public class ContactoException extends Exception{
    public ContactoException() {
        super();
    }

    public ContactoException(String message) {
        super(message);
    }
}
