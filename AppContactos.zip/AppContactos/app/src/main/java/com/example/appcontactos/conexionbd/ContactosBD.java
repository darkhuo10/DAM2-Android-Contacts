package com.example.appcontactos.conexionbd;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Contacto.class}, version = 1, exportSchema = false)
public abstract class ContactosBD extends RoomDatabase {

    private static final String NOMBRE_BD = "contactos_bd";
    private static final int NUMERO_HILOS = 4;

    public abstract ContactoDAO contactoDAO();

    public static final ExecutorService escritorBD = Executors.newFixedThreadPool(NUMERO_HILOS);
    private static volatile ContactosBD INSTANCIA;

    public static ContactosBD getContactosBD(final Context context) {
        if (INSTANCIA == null) {
            synchronized (ContactosBD.class) {
                if (INSTANCIA == null) {
                    INSTANCIA = Room.databaseBuilder(context.getApplicationContext(),
                            ContactosBD.class, NOMBRE_BD).addCallback(callbackContactos).build();
                }
            }
        }
        return INSTANCIA;
    }

    private static RoomDatabase.Callback callbackContactos = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            escritorBD.execute(() -> {
                ContactoDAO dao = INSTANCIA.contactoDAO();
                dao.deleteAll();
            });
        }
    };
}
