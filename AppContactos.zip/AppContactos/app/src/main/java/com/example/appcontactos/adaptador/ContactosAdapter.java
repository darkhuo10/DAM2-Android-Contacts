package com.example.appcontactos.adaptador;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.appcontactos.R;
import com.example.appcontactos.conexionbd.Contacto;

import java.util.ArrayList;
import java.util.List;

public class ContactosAdapter extends RecyclerView.Adapter<ContactosAdapter.ContactosViewHolder> {
    private List<Contacto> contactos = new ArrayList<>();
    private OnClickContactoListener listener;

    @NonNull
    @Override
    public ContactosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.contacto_vista_unidad, parent, false);
        return new ContactosViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactosViewHolder holder, int position) {
        Contacto contactoActual = contactos.get(position);
        holder.tvNomrbeLista.setText(contactoActual.getNombre());
        holder.ivFotoLista.setImageResource(R.drawable.ic_contacts_icon);
        holder.setContacto(contactoActual);
    }

    @Override
    public int getItemCount() {
        return contactos.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setContactos(List<Contacto> contactos) {
        this.contactos = contactos;
        notifyDataSetChanged();
    }

    public Contacto getContactoPos(int pos) {
        return contactos.get(pos);
    }

    // ViewHolder
    public class ContactosViewHolder extends RecyclerView.ViewHolder {

        TextView tvNomrbeLista;
        ImageView ivFotoLista;

        ImageButton bLlamar;
        ImageButton bCorreo;
        ImageButton bDireccion;

        Contacto contacto;
        Context context;

        public ContactosViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            tvNomrbeLista = (TextView) itemView.findViewById(R.id.tvNombreLista);
            ivFotoLista = (ImageView) itemView.findViewById(R.id.ivFotoLista);

            bLlamar = (ImageButton) itemView.findViewById(R.id.ibTelefono);
            bLlamar.setOnClickListener(view -> llamar());

            bCorreo = (ImageButton) itemView.findViewById(R.id.ibEnviar);
            bCorreo.setOnClickListener(view -> enviarCorreo());

            bDireccion = (ImageButton) itemView.findViewById(R.id.ibMaps);
            bDireccion.setOnClickListener(view -> abrirMaps());

            itemView.setOnClickListener(view -> contactoSeleccionado());
        }

        private void abrirMaps() {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + contacto.getDireccion()));
            context.startActivity(intent);
        }

        private void enviarCorreo() {
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + contacto.getEmail()));
            context.startActivity(intent);
        }

        public void setContacto(Contacto c){
            this.contacto = c;
        }

        private void llamar() {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + contacto.getTelefono()));
                context.startActivity(intent);
        }

        private void contactoSeleccionado() {
            int position = getAdapterPosition();
            if (listener != null && position != RecyclerView.NO_POSITION) {
                listener.onContactClick(contactos.get(position));
            }
        }
    }

    // Utilizada para poner un onClick pasando un contacto y no solo uno de los componentes de la vista
    public interface OnClickContactoListener {
        void onContactClick(Contacto contacto);
    }

    public void setOnClickContactoListener(OnClickContactoListener listener) {
        this.listener = listener;
    }
}
