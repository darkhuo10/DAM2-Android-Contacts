package com.example.appcontactos.conexionbd;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


import com.example.appcontactos.excepciones.ContactoEmailException;
import com.example.appcontactos.excepciones.ContactoException;
import com.example.appcontactos.excepciones.ContactoTelefonoException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Entity(tableName = "contactos_table")
public class Contacto {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "nombre")
    private String nombre;

    @ColumnInfo(name = "telefono")
    private String telefono;

    @ColumnInfo(name = "email")
    private String email;

    @ColumnInfo(name = "direccion")
    private String direccion;

    public Contacto(String nombre, String telefono, String email, String direccion) throws ContactoException {
        this.nombre = nombre;
        setTelefono(telefono);
        setEmail(email);
        this.direccion = direccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTelefono(String telefono) throws ContactoException {
        Pattern pattern = Pattern.compile("^\\d{9}$");
        Matcher matcher = pattern.matcher(telefono);
        if(matcher.matches()) {
            this.telefono = telefono;
        } else {
            throw new ContactoTelefonoException("Formato no válido.");
        }
    }
    public void setEmail(String email) throws ContactoException {
        Pattern pattern = Pattern.compile("^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if(matcher.matches()) {
            this.email = email;
        } else {
           throw new ContactoEmailException("Formato no válido.");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getDireccion() {
        return direccion;
    }

}
